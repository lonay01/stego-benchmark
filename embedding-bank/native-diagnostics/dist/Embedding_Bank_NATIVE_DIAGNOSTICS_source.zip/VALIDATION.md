# Validation

Date: 2026-09-22. Local runtime: Python3.12, PyTorch2.5.1+cpu.

- All **53 bundled Python modules** and **four notebook code cells** pass AST
  parsing. The notebook passes nbformat schema validation.
- **31 tests pass**, importing the exact release ZIP distributed with the
  notebook. The last full test run took about17 seconds on the local machine.
- CPU integration smoke covers the complete per-case workflow for each of the
  five method interfaces using explicitly synthetic test doubles: historical
  replay, baseline capture, fixed serializers, controls, reports and resume.
- Actual PyTorch tensor tests cover all five decoder normalization/threshold
  branches, encoder hooks, serializer hooks, same-latent observation, restoration
  of patched methods and unchanged RNG/output during observation.
- Other tests cover frozen complete payloads, same historical image/message
  selection, read-only original evidence, corruption refusal, terminal nonzero
  BER, technical-error history, pixel-identical PNG round trips, quantization
  rules, incomplete reports, model training-mode rejection, controller lease
  setup and completed-task reuse without environment preparation.
- Compared bundled definitions for all five methods against the actual
  `native_resolution_canary_report.zip` fetched from Drive on2026-09-22.
  All five registries match the historical `trial.json` and inference identity.
  All five historical requirements-lock hashes match their saved dependency
  identities. No replacement checkpoint/configuration was introduced.

**Not executed locally:** pretrained inference for these five methods on the
historical COCO images, isolated Linux environment installation, Google Drive
mounting, or a CUDA/A100 run of this new diagnostic notebook. Tests with synthetic
models validate the diagnostic machinery, not the research models' performance.
The notebook is ready for that real Colab check; no successful GPU result is
claimed in advance.
